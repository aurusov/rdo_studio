//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ColourPickDemo.rc
//
#define IDD_COLOURPICKDEMO_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDC_COLOURPICKER                1001
#define IDC_COLOURPICKER2               1002
#define IDC_MODE1                       1002
#define IDC_MODE2                       1003
#define IDC_TRACK                       1004
#define IDC_DISABLE                     1005
#define IDC_DEFAULT_EDIT                1006
#define IDC_CUSTOM_EDIT                 1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
